<template>
 <div class="container">
    <h2>我的</h2>
 </div>
</template>

<script>
export default {
 data() {
  return {

  }
 },
 components: {

 }
}
</script>

<style scoped lang="scss">

</style>
