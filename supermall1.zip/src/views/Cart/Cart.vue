<template>
 <div class="container">
    <h2>购物车</h2>
 </div>
</template>

<script>
export default {
 data() {
  return {

  }
 },
 components: {

 }
}
</script>

<style scoped lang="scss">

</style>
